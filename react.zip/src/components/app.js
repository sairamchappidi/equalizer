import React, { Component } from 'react';
import HorizontalCustomLabels from './slider';
export default class App extends Component {
  constructor(props) {
    super(props)
    this.state ={
      bands: ['60Hz','310Hz','1k','6k','16k'],
      modes: ['Rock','Pop','Jazz','Classical'],
      preference: '',
      initial: [50,50,50,50,50],
      Rock: [60,65,55,80,95],
      Pop: [70,50,45,70,85],
      Jazz: [40,60,35,50,75],
      Classical:[90,85,60,75,65]
    }
  }
  handleClick = (e) => {
    this.setState({
      preference: e.target.value
    })
  }
  render() {
    const { bands, modes, initial, Rock, Pop, Jazz, Classical, preference } = this.state;
    let bandValues = preference == 'Rock' ? Rock : preference == 'Pop' ? Pop : preference == 'Rock' ? Rock : preference == 'Jazz' ? Jazz : preference == 'Classical' ? Classical : initial;
    return (
      <div className="container">
        <div className="clearfix col-xs-7">
          {
            bands.map((band,index) => {
              let slideValue = bandValues[index]
              return (
                <HorizontalCustomLabels 
                  band={band}
                  key={index}
                  slideValue={slideValue}
                />
              )
            })
          }
        </div>
        <div className="col-xs-5 ">
          <select onChange={this.handleClick} >
            <option value="" disabled="disabled" selected="selected">Preset</option>
              {
                modes.map((mode,index) =>{
                  return (
                    <option value={mode} key={index}>{mode}</option>
                  )
                })
              }
            
        </select>
        </div>
      </div>
    )
  }
}