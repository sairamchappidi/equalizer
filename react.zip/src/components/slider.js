import React, { Component } from 'react';
import Slider from 'react-rangeslider';


class HorizontalCustomLabels extends Component {
  constructor (props, context) {
    super(props, context)
   
  }

 handleChangeHorizontal = (value) => {
     console.log(value);
 }

  render () {
    const { band, slideValue } = this.props;
    const horizontalLabels = {
      0: 'Low',
      50: 'Medium',
      100: 'High'
    }

    return (
      <div className='slider custom-labels'>
        <Slider
          min={0}
          max={100}
          value={slideValue}
          labels={horizontalLabels}
          orientation="vertical"
          onChange={this.handleChangeHorizontal}
        />
        <div className='text_align_center'>{band}</div>
      </div>
    )
  }
}

export default HorizontalCustomLabels;
